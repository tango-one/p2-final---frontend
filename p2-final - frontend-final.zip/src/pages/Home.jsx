import React from "react";
import Hero from "../components/Hero";

const Home = () => {
  return (
    <div className="container">
      <Hero />
    </div>
  );
};

export default Home;
