import React from "react";
import RegisterForm from "../components/Register";

const Register = () => {
  return (
    <div className="container">
      <RegisterForm />
    </div>
  );
};

export default Register;
